# Paralysis C2
a Python C2 written from scratch

# Usage
1. edit everything in the `config.json` file
2. run the python file
3. connect over a RAW socket to the C2 port
4. profit.